package org.vb.pokr.messages;


public class MsgJoinGame extends Message {

	/**
	 * 
	 */
	private static final long serialVersionUID = -949517274522859369L;
	
	final public static int TYPE = 0x10000000; 
	
	@SuppressWarnings("unused")
	private MsgJoinGame() {}
	
	public MsgJoinGame(long sid) {
		super(TYPE, sid);
	}
}
