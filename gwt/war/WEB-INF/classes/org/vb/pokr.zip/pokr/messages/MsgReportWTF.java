package org.vb.pokr.messages;

public class MsgReportWTF extends Message {
	
	private static final long serialVersionUID = 7275042556828329731L;
	
	final static public int TYPE = 0xFEEDBEEF;
	public String comnt;
	public int pid;
	@SuppressWarnings("unused")
	private MsgReportWTF() {}
	
	public MsgReportWTF(long sid, int pid) {
		super(TYPE, sid);
		this.pid = pid;
	}

}
