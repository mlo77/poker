package org.vb.pokr.messages;

import java.io.Serializable;

public abstract class Message implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1321037481107414475L;
	private int type;
	public long sid;// the session id
	
	protected Message() {}
	
	protected Message(int type, long sid) {
		this.type = type;
		this.sid = sid;
	}

	public int getType() {
		return type;
	}
	
}
