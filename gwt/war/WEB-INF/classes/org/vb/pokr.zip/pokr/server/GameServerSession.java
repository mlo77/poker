package org.vb.pokr.server;

import org.vb.pokr.messages.MsgCmd;
import org.vb.pokr.shared.GameState;

import app.main.Player;
import app.main.PokrInterpreter;
import app.main.Status;

public class GameServerSession extends PokrInterpreter {

	public long sid;
	private int actionCount;
	private int[] playrsMarkr = new int[10]; 
	public int[] lastAct = new int[3];
	public String sessName;
	
	public GameServerSession(long sid, String sessName) {
		this.sid = sid;
		if (null != sessName) this.sessName = sessName;
		else this.sessName = Long.toString(sid);
	}
	
	public void playerJoins() {
		pitb.addPlayers(1);
	}
	
	public int getPlayerCount() {
		return pitb.players.size();
	}

	public int getMarkr(int pid) {
		return playrsMarkr[pid];
	}
	
	public int process(MsgCmd m) {
		if (m.pid != pitb.currentP.getId()) return Status.POKR_NOT_TURN_TO_PLAY;
		String[] inputs = m.cmd.split(" ");
		int code = cmdCode(inputs[0]);
		int res = doAction(code, inputs, m.cmd);
		if (Status.POKR_OK == res) {
			postAction(code, inputs, m);
			actionCount++;
			playrsMarkr[m.pid] = actionCount;
		}
		return playrsMarkr[m.pid];
	}
	
	private void postAction(int code, String[] inputs, MsgCmd m) {
		lastAct[0] = m.pid;
		lastAct[1] = code;
		if (code == CMD_RAISE) {
			lastAct[2] = Integer.parseInt(inputs[1]);
			return;
		}
		lastAct[2] = -1;
	}

	public String printGameState(int pid) {
		String r = new String();
		if (inGame) {
			for (int i=pitb.playing.size()-1; i>=0; i--) {
				Player p = pitb.playing.get(i);
				if (pid == p.getId())
					r += "-> ";
				r += p + "\n";
			}
			r += pitb.board + "\n";
			r += pitb.pot + "\n";
			r += "turn left : " + pitb.turnLeft + "\n";
		}
		return r;
	}
	
	public GameState getGameStateIfUpdatedFor(int pid) {
		if (playrsMarkr[pid] == actionCount) return null;
		return getGameStateFor(pid);
	}
	
	public GameState getGameStateFor(int pid) {
		GameState r = new GameState();
		
		r.board = new int[pitb.board.cardsCount()];
		for (int i=pitb.board.cardsCount()-1; i>=0; i--)
			r.board[i] = pitb.board.card(i);
		r.pot = new int[2];
		r.pot[0] = pitb.pot.getBetPot();
		r.pot[1] = pitb.pot.getMaxBet();
		r.players = new int[pitb.playing.size()][4];
		for (int i=pitb.playing.size()-1; i>=0; i--) {
			Player p = pitb.playing.get(i);
			if (p.getId() != pid) { // other players cards hidden
				r.players[i][0] = -1;
				r.players[i][1] = -1;
			}
			else {
				r.players[i][0] = p.card(0);
				r.players[i][1] = p.card(1);
			}
			r.players[i][2] = p.cash;
			r.players[i][3] = p.betRound;
		}
		r.lastAct = new int[3];
		for (int i=0; i<3; i++)
			r.lastAct[i] = this.lastAct[i];
		
		return r;
	}
	
	public String toString() {
		return sessName;
	}
}
