package org.vb.pokr.messages;

import com.google.gwt.user.client.ui.HTML;


public class MsgJoinGameRes extends Message {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1570272762501746018L;
	
	public int pid;
	public String sidName;
	//public HTML gstate; 
	final public static int TYPE = 0x10000001;
	
	@SuppressWarnings("unused")
	private MsgJoinGameRes() {}
	
	public MsgJoinGameRes(int pid, long sid, String name) {
		super(TYPE, sid);
		this.pid = pid;
		this.sidName = name;
	}

}
