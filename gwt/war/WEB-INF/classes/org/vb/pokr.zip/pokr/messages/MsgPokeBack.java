package org.vb.pokr.messages;

import org.vb.pokr.shared.GameState;

public class MsgPokeBack extends Message {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5742176292188883834L;
	public static final int TYPE = 0x00040001;
	public long[] sidFocused; // 5 max
	public GameState[] gStates;
	
	
	@SuppressWarnings("unused")
	//private MsgReqSessUpdtRes() {}
	
	public MsgPokeBack() {
		super(TYPE, -1);
	}
	
	
}
