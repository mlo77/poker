package org.vb.pokr.client;

import org.vb.pokr.client.PokerGameWebApp.MessageReceiver;
import org.vb.pokr.messages.MsgQueryGameState;


import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.HTML;

public class GameSession extends HTML {
	public long sid;
	public int pid;
	CommServiceAsync requestService;
	public int pidMarkr;
	public GameSession(long sid, int pid, String s) {
		super(s);
		this.pid = pid;
		this.sid = sid;
		//this.requestService = requestService;
	}
	public void update(MessageReceiver mReceivr) {
		requestService.sendMessage(new MsgQueryGameState(pid, sid), mReceivr);
	}
}
