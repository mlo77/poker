package org.vb.pokr.shared;

import com.google.gwt.user.client.rpc.IsSerializable;

public class GameState implements IsSerializable {
	public int[] board; // 5 int max
	public int[] pot; // pot bet, bet round
	public int[][] players; // for each 2 cards, cash, betting
	public int[] lastAct; // pid, cmd code, amount involved
	public GameState() {
	}
}
