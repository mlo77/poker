package org.vb.pokr.messages;

public class MsgCreateGame extends Message {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7842086087917271568L;
	public static final int TYPE = 0x10000002;
	public String sessName;
	
	public MsgCreateGame() {
		super(TYPE, -1);
	}
}
