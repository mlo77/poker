package org.vb.pokr.messages;

@SuppressWarnings("serial")
public class MsgQuerySess extends Message {
	private static final long serialVersionUID = -624123955428746078L;
	final static public int TYPE = 0x00050000;
	public MsgQuerySess() {
		super(TYPE, -1);
	}
}
