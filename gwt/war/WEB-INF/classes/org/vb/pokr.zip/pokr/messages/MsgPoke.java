package org.vb.pokr.messages;

public class MsgPoke extends Message {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5742176292188883834L;
	public static final int TYPE = 0x00040000;
	public int pid;
	public long[] sidFocused = new long[5];
	@SuppressWarnings("unused")
	private MsgPoke() {}
	
	public MsgPoke(int pid) {
		super(TYPE, -1);
		this.pid = pid;
	}
	
	
}
