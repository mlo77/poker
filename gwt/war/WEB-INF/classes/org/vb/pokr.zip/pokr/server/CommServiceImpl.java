package org.vb.pokr.server;

import org.vb.pokr.client.CommService;
import org.vb.pokr.messages.*;
import org.vb.pokr.shared.GameState;


import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class CommServiceImpl extends RemoteServiceServlet implements CommService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final int MAX_ALLOWED_POKED_SID = 5;

	@Override
	public Message sendMessage(Message msg) throws IllegalArgumentException {
		switch (msg.getType()) {
		case MsgCreateGame.TYPE :
			{
			MsgCreateGame m = (MsgCreateGame) msg;
			GameServerSession gs = SessionMgr.getInstance().findOrCreateAndJoinSession(m.sid, m.sessName);
			return new MsgJoinGameRes(gs.getPlayerCount(), gs.sid, gs.toString());
			}
		case MsgJoinGame.TYPE : 
			{
			MsgJoinGame m = (MsgJoinGame) msg;
			GameServerSession gs = SessionMgr.getInstance().findSession(m.sid);
			if (gs==null) new MsgJoinGameRes(gs.getPlayerCount(), gs.sid, gs.toString());
			return new MsgJoinGameRes(gs.getPlayerCount(), gs.sid, gs.toString());
			}
		case MsgCmd.TYPE :
			{
			MsgCmd m = (MsgCmd) msg;
			GameServerSession gs = SessionMgr.getInstance().findSession(m.sid);
			if (gs == null) return new MsgCmdRes(m.sid, -1, null);
			return new MsgCmdRes(m.sid, gs.process(m), gs.getGameStateFor(m.pid));
			}
		case MsgQueryGameState.TYPE :
			{
			MsgQueryGameState m = (MsgQueryGameState) msg;
			GameServerSession gs = SessionMgr.getInstance().findSession(msg.sid);
			if (gs == null) return new MsgGameState(m.sid, null);
			return new MsgGameState(m.sid, gs.getGameStateIfUpdatedFor(m.pid));
			}
		case MsgQuerySess.TYPE :
			{
			MsgGameSessions	m = new MsgGameSessions();
			m.sidList = SessionMgr.getInstance().sidList;
			return m;
			}
		case MsgPoke.TYPE :
			{
			MsgPoke m = (MsgPoke) msg;
			int len = Math.min(m.sidFocused.length, MAX_ALLOWED_POKED_SID);
			if (len == 0) return null;
			long[] sf_temp = new long[len];
			GameState[] gst_temp = new GameState[len];
			int count = 0;
			for (int i=0; i<len; i++) {
				GameServerSession gs = SessionMgr.getInstance().findSession(m.sidFocused[i]);
				GameState gst = gs.getGameStateIfUpdatedFor(m.pid);
				if (gst == null) continue;
				sf_temp[count] = m.sidFocused[i];
				gst_temp[count++] = gst;
			}
			if (count == 0) return null;
			MsgPokeBack r = new MsgPokeBack();
			r.sidFocused = new long[count];
			r.gStates = new GameState[count];
			for (int i=0; i<len; i++) {
				r.sidFocused[i] = sf_temp[i];
				r.gStates[i] = gst_temp[i];
			}
			return r;
			}
		case MsgReportWTF.TYPE :
			{
			}
		default :
			break;
		}
		return null;
	}

	@Override
	public void postMessage(Message msg) {
		
	}

}
