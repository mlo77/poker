package org.vb.pokr.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;



import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.cell.client.ClickableTextCell;
import com.google.gwt.cell.client.TextCell;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.cellview.client.CellList;
import com.google.gwt.user.cellview.client.HasKeyboardPagingPolicy.KeyboardPagingPolicy;
import com.google.gwt.user.cellview.client.HasKeyboardSelectionPolicy.KeyboardSelectionPolicy;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.rpc.AsyncCallback;
import java.util.Arrays;

import org.vb.pokr.messages.*;
import org.vb.pokr.shared.SidAndName;

import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TabLayoutPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.ListDataProvider;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.gwt.view.client.SingleSelectionModel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class PokerGameWebApp implements EntryPoint {
	
	/**
	 * The message displayed to the user when the server cannot be reached or
	 * returns an error.
	 */
	private static final String SERVER_ERROR = "An error occurred while "
			+ "attempting to contact the server. Please check your network "
			+ "connection and try again.";

	/**
	 * Create a remote service proxy to talk to the server-side Greeting service.
	 */
	static private final CommServiceAsync requestService = GWT
			.create(CommService.class);
	
	
	// The list of data to display.
	private static final List<String> DAYS = Arrays.asList("Sunday", "Monday",
	"Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");

	private ArrayList<SidAndName> availSessions;
	private ArrayList<String> availSessionsStr;
	

	DialogBox dialogBox;
	Button closeButton;
	Label textToServerLabel;
	HTML serverResponseLabel;
	TabLayoutPanel tabPanel;
	ArrayList<GameSession> playedSessions;
	Integer currentTab;
	GameSession selectedGS;
	Button sendButton;
	Button joinButton;
	Button createButton;
	TextBox cmdField;
	TextBox joinField;
	
	Pollr periodicPoll;
	final static private int PERIODIC = 2000;
	ListDataProvider<String> dataProvider;
	MessageReceiver mReceivr;
	
	public void onModuleLoad() {
	 
		dialogBox = new DialogBox();
		closeButton = new Button("Close");
		textToServerLabel = new Label();
		serverResponseLabel = new HTML();
		tabPanel = new TabLayoutPanel(2.5, Unit.EM);
		playedSessions = new ArrayList<GameSession>();
		sendButton = new Button("Send");
		joinButton = new Button("Join Game");
		createButton = new Button("Create Game");
		cmdField = new TextBox();
		joinField = new TextBox();
		dataProvider = new ListDataProvider<String>();
		
		mReceivr = new MessageReceiver(this);
		
		// retrieve the list of all sessions available
		requestService.sendMessage(new MsgQuerySess(), mReceivr); 
		
	    tabPanel.setSize("600px", "828px");
	    tabPanel.setAnimationDuration(1000);
	    tabPanel.getElement().getStyle().setMarginBottom(10.0, Unit.PX);
	    tabPanel.addSelectionHandler(new SelectionHandler<Integer>() {
			@Override
			public void onSelection(SelectionEvent<Integer> event) {
				currentTab = event.getSelectedItem();
				((Label)(tabPanel.getTabWidget(currentTab))).setStyleName("gwt-TabBarItem-selected");
				GameSession gs = (GameSession) tabPanel.getWidget(currentTab);
				assert gs != null : "bad game session";
				selectedGS = gs;
				}
	    });
	    periodicPoll = new Pollr(this);
		
	    HorizontalPanel hp = new HorizontalPanel();
	    RootPanel.get().add(hp);
	    

		    // Create a cell to render each value in the list.
	    TextCell textCell = new TextCell();
		
		// Create a CellList that uses the cell.
		CellList<String> cellList = new CellList<String>(textCell);
		cellList.setKeyboardSelectionPolicy(KeyboardSelectionPolicy.ENABLED);
	    // Add a selection model to handle user selection.
	    final SingleSelectionModel<String> selectionModel = new SingleSelectionModel<String>();
	    cellList.setSelectionModel(selectionModel);
	    selectionModel.addSelectionChangeHandler(new SelectionChangeEvent.Handler() {
	      public void onSelectionChange(SelectionChangeEvent event) {
	        String selected = selectionModel.getSelectedObject();
	        if (selected != null) {
	          GWT.log("You selected: " + selected);
	          joinField.setText(selected);	      
	        }
	      }
	    });

		
		// Set the range to display. In this case, our visible range is smaller than
		// the data set.
		//cellList.setPageSize(30);
		//cellList.setKeyboardPagingPolicy(KeyboardPagingPolicy.INCREASE_RANGE);
		//cellList.setKeyboardSelectionPolicy(KeyboardSelectionPolicy.BOUND_TO_SELECTION);
		
		// Create a data provider.
		//ListDataProvider<String> dataProvider = new ListDataProvider<String>();
		
		// Connect the list to the data provider.
		dataProvider.addDataDisplay(cellList);
		
		// Add the data to the data provider, which automatically pushes it to the
		// widget. Our data provider will have seven values, but it will only push
		// the four that are in range to the list.
		List<String> list = dataProvider.getList();
		for (String day : DAYS) {
			list.add(day);
		}	    
		
	    
		cmdField.setText("your name");
		final Label errorLabel = new Label();

		// We can add style names to widgets
		sendButton.addStyleName("sendButton");

		VerticalPanel vp = new VerticalPanel();
		vp.add(createButton);
	    vp.add(cmdField);
	    vp.add(sendButton);
	    vp.add(errorLabel);
		// Add the nameField and sendButton to the RootPanel
		// Use RootPanel.get() to get the entire body element
		//RootPanel.get("cmdFieldContainer").add(nameField);
		//RootPanel.get("sendButtonContainer").add(sendButton);
		//RootPanel.get("errorLabelContainer").add(errorLabel);
		
	    vp.add(new Label("Available sessions"));
	    vp.add(cellList);
	    vp.add(joinButton);
	    
	    hp.add(vp);
	    hp.add(tabPanel);	
		
		// Focus the cursor on the name field when the app loads
		cmdField.setFocus(true);
		cmdField.selectAll();

		// Create the popup dialog box
		dialogBox.setText("Remote Procedure Call");
		dialogBox.setAnimationEnabled(true);
		// We can set the id of a widget by accessing its Element
		closeButton.getElement().setId("closeButton");
		VerticalPanel dialogVPanel = new VerticalPanel();
		dialogVPanel.addStyleName("dialogVPanel");
		dialogVPanel.add(new HTML("<b>Sending name to the server:</b>"));
		dialogVPanel.add(textToServerLabel);
		dialogVPanel.add(new HTML("<br><b>Server replies:</b>"));
		dialogVPanel.add(serverResponseLabel);
		dialogVPanel.setHorizontalAlignment(VerticalPanel.ALIGN_RIGHT);
		dialogVPanel.add(closeButton);
		dialogBox.setWidget(dialogVPanel);

		// Add a handler to close the DialogBox
		closeButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				dialogBox.hide();
				sendButton.setEnabled(true);
				sendButton.setFocus(true);
			}
		});

		// Create a handler for the sendButton and nameField
		class SendHandler implements ClickHandler, KeyUpHandler {

			PokerGameWebApp app;
			SendHandler(PokerGameWebApp app) {
				this.app = app;
			}
			
			public void onClick(ClickEvent event) {
				sendToServer();
			}

			// Fired when the user types in the nameField.
			public void onKeyUp(KeyUpEvent event) {
				if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {
					sendToServer();
				}
			}

			private void sendToServer() {
				// First, we validate the input.
				errorLabel.setText("");
				String textToServer = cmdField.getText();
		
				// Then, we send the input to the server.
				sendButton.setEnabled(false);
				textToServerLabel.setText(textToServer);
				serverResponseLabel.setText("");
				requestService.sendMessage(new MsgCmd(selectedGS.sid, selectedGS.pid, textToServer), mReceivr);
			}
			
		}

		// Add a handler to send the name to the server
		SendHandler sh = new SendHandler(this);
		sendButton.addClickHandler(sh);
		cmdField.addKeyUpHandler(sh);
		sendButton.setEnabled(false);
		joinButton.setEnabled(false);
		
		createButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				requestService.sendMessage(new MsgCreateGame(), mReceivr);
			}
		});
		
		joinButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				requestService.sendMessage(new MsgJoinGame(Long.valueOf(joinField.getText())), mReceivr);
			}
		});
		//periodicPoll.schedule(PERIODIC);
	}
	
	protected void processMsg(Message result) {	
		switch (result.getType()) {
		case MsgCmdRes.TYPE : 
			pMCRslt((MsgCmdRes) result);
		case MsgGameState.TYPE :
			pMGStt((MsgGameState) result);
			break;
		case MsgJoinGameRes.TYPE :
			pMGJnd((MsgJoinGameRes) result);
			break;
		case MsgGameSessions.TYPE :
			pMGSss((MsgGameSessions)result);
			break;
		default :
			break;
		}
	}
	
	private void pMGSss(MsgGameSessions m) {
		// TODO Auto-generated method stub
		GWT.log("pMGSss");
		availSessions = m.sidList;
		availSessionsStr = new ArrayList<String>();
		int s = availSessions.size();
		for (int i=0; i<s; i++) 
			availSessionsStr.add(availSessions.get(i).name);
		List<String> l = dataProvider.getList();
		l.clear();
		for (String n : availSessionsStr)
			l.add(n);
		if (l.size() != 0) 
			joinButton.setEnabled(true);
		else
			joinButton.setEnabled(false);
	}

	private void pMCRslt(MsgCmdRes m) {
		GameSession gs = findGS(m.sid);

	}
	
	private GameSession findGS(long sid) {
		// TODO Auto-generated method stub
		return null;
	}

	private void pMGStt(MsgGameState m) {
		/*
		int i=0;
		GameSession gs=null;
		for (i=Sessions.size()-1; i>=0; i--) {
			gs = Sessions.get(i);
			if (gs.sid == m.sid)
				break;
		}
		if (i==-1) return;
		gs.setHTML(m.state);
		*/
	}
	
	private void pMGJnd(MsgJoinGameRes m) {
		GameSession gs = new GameSession(m.sid, m.pid, m.sidName);
		playedSessions.add(gs);
		tabPanel.add(gs, new Label(Long.toString(m.sid)));
		sendButton.setEnabled(true);
	}

	private void processMsgQueryUpdateResult(MsgGameSessions m) {
		/*
		if (m.sidUpdatedList != null) {
			for (int i = m.sidUpdatedList.size()-1; i>=0; i--) {
				if (selectedGS.sid == m.sidUpdatedList.get(i)) {
					requestService.sendMessage(new MsgQueryGameState(selectedGS.pid, selectedGS.sid), mReceivr);
					continue;
				}
				((Label)(tabPanel.getTabWidget(i))).setStyleName("gwt-TabLabelUpdated");
			}
		}
		if (m.requestToMakeList != null) {
			for (int i=m.requestToMakeList.size()-1; i>=0; i--) {
				if (MsgPoke.TYPE == m.requestToMakeList.get(i))
					requestService.sendMessage(new MsgPoke(selectedGS.pid, selectedGS.pidMarkr), mReceivr);
			}
		}
		*/
	}
	
	private void displayErrorBox(String s) {
		dialogBox.setText(s);
		serverResponseLabel.addStyleName("serverResponseLabelError");
		serverResponseLabel.setHTML(SERVER_ERROR);
		dialogBox.center();
		closeButton.setFocus(true);
	}
	
	class Pollr extends Timer {

		PokerGameWebApp app;
		Pollr(PokerGameWebApp app) {
			this.app = app;
		}
		
		@Override
		public void run() {
			if (playedSessions.size() == 0) return;
			GameSession gs = playedSessions.get(0);
			MsgPoke m = new MsgPoke(gs.pid);
			m.sidFocused[0] = gs.sid;
			requestService.sendMessage(m, app.mReceivr);
			this.schedule(PERIODIC);
		}
	}
	
	class GameSessionCell extends AbstractCell<String> {

		@Override
		public void render(com.google.gwt.cell.client.Cell.Context context,
				String value, SafeHtmlBuilder sb) {
			// TODO Auto-generated method stub
			
		}
	}
	
	class MessageReceiver implements AsyncCallback<Message> {

		PokerGameWebApp app;
		
		MessageReceiver(PokerGameWebApp app) {
			this.app = app;
		}
		
		@Override
		public void onFailure(Throwable caught) {
			app.displayErrorBox("Remote Procedure Call - Failure");
		}

		@Override
		public void onSuccess(Message result) {
			app.processMsg(result);
		}
		
	}
}


