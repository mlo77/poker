package org.vb.pokr.messages;

import org.vb.pokr.shared.GameState;

public class MsgCmdRes extends MsgGameState {

	private static final long serialVersionUID = 9050049683405569166L;
	final public static int TYPE = 0x00030001;
	public int cmdStatus;
	@SuppressWarnings("unused")
	private MsgCmdRes() {super(TYPE, 0, null);}
	
	public MsgCmdRes(long sid, int cmdStatus, GameState state) {
		super(TYPE, sid, state);
		this.cmdStatus = cmdStatus;
	}
}
